from flask import Flask, request, render_template
import numpy as np
import pandas as pd
import pickle
import ast

app = Flask(__name__)

# ── Load datasets ──────────────────────────────────────────────────────────────
sym_des     = pd.read_csv("datasets/symtoms_df.csv")
precautions = pd.read_csv("datasets/precautions_df.csv")
workout     = pd.read_csv("datasets/workout_df.csv")
description = pd.read_csv("datasets/description.csv")
medications = pd.read_csv("datasets/medications.csv")
diets       = pd.read_csv("datasets/diets.csv")

# ── Load model ─────────────────────────────────────────────────────────────────
svc = pickle.load(open("models/svc.pkl", "rb"))

# ── Build symptom/disease mappings from Training.csv ──────────────────────────
_training     = pd.read_csv("datasets/Training.csv")
symptoms_dict = {symptom: idx for idx, symptom in enumerate(_training.columns[:-1])}
diseases_list = {
    idx: disease
    for idx, disease in enumerate(sorted(_training["prognosis"].unique()))
}

# ── Helper ─────────────────────────────────────────────────────────────────────
def parse_list_field(val):
    """Safely parse a stringified Python list from CSV."""
    if isinstance(val, list):
        return val
    try:
        return ast.literal_eval(val)
    except Exception:
        return [str(val)]

def helper(dis):
    desc_row = description[description["Disease"] == dis]["Description"].values
    desc     = desc_row[0] if len(desc_row) else "No description available."

    pre_row  = precautions[precautions["Disease"] == dis][
        ["Precaution_1", "Precaution_2", "Precaution_3", "Precaution_4"]
    ]
    prec_list = [p for p in pre_row.values.flatten().tolist() if pd.notna(p) and str(p).strip()]

    med_row  = medications[medications["Disease"] == dis]["Medication"].values
    med_list = parse_list_field(med_row[0]) if len(med_row) else []

    diet_row  = diets[diets["Disease"] == dis]["Diet"].values
    diet_list = parse_list_field(diet_row[0]) if len(diet_row) else []

    wrkout_list = workout[workout["disease"] == dis]["workout"].values.tolist()

    return desc, prec_list, med_list, diet_list, wrkout_list

# ── Prediction ─────────────────────────────────────────────────────────────────
def get_predicted_value(patient_symptoms):
    input_vector = np.zeros(len(symptoms_dict))
    unrecognized = []
    for s in patient_symptoms:
        key = s.strip().lower().replace(" ", "_")
        if key in symptoms_dict:
            input_vector[symptoms_dict[key]] = 1
        else:
            unrecognized.append(s)
    prediction_idx = svc.predict([input_vector])[0]
    return diseases_list[prediction_idx], unrecognized

# ── Routes ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["GET", "POST"])
def predict():
    if request.method == "POST":
        symptoms_raw = request.form.get("symptoms", "").strip()
        if not symptoms_raw:
            return render_template("index.html",
                                   message="Please enter at least one symptom.")

        user_symptoms = [s.strip() for s in symptoms_raw.split(",") if s.strip()]
        try:
            predicted_disease, unrecognized = get_predicted_value(user_symptoms)
            dis_des, my_precautions, my_medications, rec_diet, my_workout = helper(predicted_disease)
            warn = f"Note: symptom(s) not recognized: {', '.join(unrecognized)}" if unrecognized else None
            return render_template(
                "index.html",
                predicted_disease=predicted_disease,
                dis_des=dis_des,
                my_precautions=my_precautions,
                medications=my_medications,
                my_diet=rec_diet,
                workout=my_workout,
                warning=warn,
            )
        except Exception as e:
            return render_template("index.html", message=f"Prediction error: {e}")

    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/developer")
def developer():
    return render_template("developer.html")

@app.route("/blog")
def blog():
    return render_template("blog.html")

if __name__ == "__main__":
    app.run(debug=True)
